export interface Article {
  id: number;
  title: string;
  slug: string;
  summary: string;
  content: string;
  category: string;
  image_url: string;
  source_name: string;
  source_url: string;
  created_at: string;
  updated_at: string;
  views: number;
}

const categories = ['Nasional', 'Politik', 'Ekonomi', 'Teknologi', 'Olahraga', 'Internasional', 'Gaya Hidup', 'Hukum'];

export const CATEGORIES = categories;

export const articles: Article[] = [
  {
    id: 1,
    title: 'Pemerintah Luncurkan Program Digitalisasi UMKM Nasional Senilai Rp15 Triliun',
    slug: 'pemerintah-luncurkan-program-digitalisasi-umkm-nasional',
    summary: 'Kementerian Koperasi dan UKM resmi meluncurkan program transformasi digital bagi pelaku usaha mikro, kecil, dan menengah dengan alokasi anggaran mencapai Rp15 triliun untuk tahun fiskal 2025.',
    content: `<p>Jakarta — Kementerian Koperasi dan Usaha Kecil Menengah (UKM) resmi meluncurkan program transformasi digital berskala nasional yang ditujukan bagi pelaku Usaha Mikro, Kecil, dan Menengah (UMKM) di seluruh Indonesia. Program ini dialokasikan anggaran sebesar Rp15 triliun untuk tahun fiskal 2025.</p>
<h2>Poin Utama</h2>
<ul>
<li>Program mencakup pelatihan digital marketing, integrasi e-commerce, dan sistem pembayaran digital</li>
<li>Target 5 juta UMKM terdigitalisasi pada akhir 2025</li>
<li>Kolaborasi dengan 12 platform digital nasional</li>
<li>Subsidi infrastruktur teknologi bagi UMKM di daerah 3T</li>
</ul>
<p>Menteri Koperasi dan UKM menyatakan bahwa program ini merupakan langkah strategis untuk meningkatkan daya saing UMKM Indonesia di pasar global. "Transformasi digital bukan lagi pilihan, melainkan keharusan bagi pelaku UMKM untuk bertahan dan berkembang di era ekonomi digital," ujar sang Menteri dalam konferensi pers di Jakarta.</p>
<p>Program ini akan dilaksanakan secara bertahap, dimulai dari kota-kota besar di Pulau Jawa dan Sumatera, kemudian diperluas ke wilayah Indonesia Timur pada semester kedua 2025.</p>
<blockquote>Catatan Redaksi: Program digitalisasi UMKM ini dinilai sebagai salah satu langkah paling ambisius pemerintah dalam dekade terakhir. Keberhasilannya akan sangat bergantung pada kesiapan infrastruktur digital di daerah-daerah terpencil.</blockquote>`,
    category: 'Ekonomi',
    image_url: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&h=450&fit=crop',
    source_name: 'Antara',
    source_url: 'https://antara.go.id/1',
    created_at: '2025-01-15T08:30:00Z',
    updated_at: '2025-01-15T08:30:00Z',
    views: 15420
  },
  {
    id: 2,
    title: 'KPU Tetapkan Jadwal Pemilihan Kepala Daerah Serentak 2025 di 270 Wilayah',
    slug: 'kpu-tetapkan-jadwal-pilkada-serentak-2025',
    summary: 'Komisi Pemilihan Umum menetapkan jadwal resmi Pemilihan Kepala Daerah serentak yang akan digelar di 270 kabupaten dan kota di seluruh Indonesia pada November 2025.',
    content: `<p>Jakarta — Komisi Pemilihan Umum (KPU) Republik Indonesia telah menetapkan jadwal resmi penyelenggaraan Pemilihan Kepala Daerah (Pilkada) serentak tahun 2025. Pemilihan akan digelar secara bersamaan di 270 kabupaten dan kota di seluruh Indonesia.</p>
<h2>Poin Utama</h2>
<ul>
<li>Pilkada serentak dijadwalkan pada 27 November 2025</li>
<li>Melibatkan 270 daerah kabupaten dan kota</li>
<li>Pendaftaran calon dibuka mulai Agustus 2025</li>
<li>Anggaran total diperkirakan mencapai Rp28 triliun</li>
</ul>
<p>Ketua KPU menegaskan bahwa persiapan logistik dan teknis sudah dimulai sejak awal tahun. Pemutakhiran data pemilih juga tengah dilakukan secara intensif untuk memastikan akurasi Daftar Pemilih Tetap (DPT).</p>
<p>"Kami berkomitmen menyelenggarakan Pilkada yang transparan, akuntabel, dan bermartabat. Partisipasi masyarakat menjadi kunci keberhasilan pesta demokrasi ini," tegas Ketua KPU.</p>
<blockquote>Catatan Redaksi: Pilkada serentak 2025 menjadi ujian besar bagi konsolidasi demokrasi di tingkat lokal. Pengawasan ketat terhadap potensi politik uang dan kampanye hitam perlu menjadi prioritas.</blockquote>`,
    category: 'Politik',
    image_url: 'https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?w=800&h=450&fit=crop',
    source_name: 'Tempo',
    source_url: 'https://tempo.co/2',
    created_at: '2025-01-15T07:15:00Z',
    updated_at: '2025-01-15T07:15:00Z',
    views: 23100
  },
  {
    id: 3,
    title: 'Indonesia Raih Emas di Kejuaraan Bulu Tangkis Asia: Ginting Tampil Gemilang',
    slug: 'indonesia-raih-emas-bulu-tangkis-asia-ginting',
    summary: 'Anthony Sinisuka Ginting membawa Indonesia meraih medali emas di Kejuaraan Bulu Tangkis Asia 2025 setelah mengalahkan wakil Tiongkok dalam final dramatis tiga set.',
    content: `<p>Manila — Anthony Sinisuka Ginting berhasil membawa Indonesia meraih medali emas di Kejuaraan Bulu Tangkis Asia 2025 yang digelar di Manila, Filipina. Dalam partai final tunggal putra, Ginting mengalahkan wakil Tiongkok dalam pertandingan dramatis yang berlangsung tiga set.</p>
<h2>Poin Utama</h2>
<ul>
<li>Ginting menang 21-19, 18-21, 21-17 dalam final tiga set</li>
<li>Ini merupakan emas pertama Indonesia di Kejuaraan Asia sejak 2019</li>
<li>Indonesia juga meraih perak di sektor ganda campuran</li>
<li>Total perolehan medali Indonesia: 1 emas, 1 perak, 2 perunggu</li>
</ul>
<p>Ginting menampilkan performa luar biasa sepanjang turnamen, tidak kehilangan satu set pun hingga babak semifinal. Di partai puncak, ia harus berjuang keras melawan stamina dan ketajaman lawan.</p>
<p>"Saya bermain untuk Indonesia, untuk seluruh rakyat Indonesia. Tekanan di final sangat besar, tapi dukungan dari seluruh tanah air membuat saya terus berjuang," ujar Ginting usai pertandingan.</p>
<blockquote>Catatan Redaksi: Prestasi Ginting ini menjadi angin segar bagi bulu tangkis Indonesia yang sempat mengalami masa sulit. Regenerasi pemain muda perlu terus diprioritaskan.</blockquote>`,
    category: 'Olahraga',
    image_url: 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=800&h=450&fit=crop',
    source_name: 'Detik',
    source_url: 'https://detik.com/3',
    created_at: '2025-01-15T06:00:00Z',
    updated_at: '2025-01-15T06:00:00Z',
    views: 45200
  },
  {
    id: 4,
    title: 'Bank Indonesia Pertahankan Suku Bunga Acuan di Level 5,75 Persen',
    slug: 'bank-indonesia-pertahankan-suku-bunga-acuan',
    summary: 'Rapat Dewan Gubernur Bank Indonesia memutuskan untuk mempertahankan suku bunga acuan BI-Rate di level 5,75% demi menjaga stabilitas nilai tukar rupiah.',
    content: `<p>Jakarta — Bank Indonesia (BI) memutuskan untuk mempertahankan suku bunga acuan BI 7-Day Reverse Repo Rate di level 5,75% dalam Rapat Dewan Gubernur (RDG) yang berlangsung pada 14-15 Januari 2025.</p>
<h2>Poin Utama</h2>
<ul>
<li>BI-Rate tetap di 5,75%, deposit facility rate 5,00%, lending facility rate 6,50%</li>
<li>Keputusan untuk menjaga stabilitas nilai tukar rupiah</li>
<li>Inflasi Januari diproyeksikan tetap terkendali di koridor 2,5±1%</li>
<li>Pertumbuhan ekonomi Q1 2025 diperkirakan 5,0-5,4%</li>
</ul>
<p>Gubernur BI menyatakan keputusan ini konsisten dengan upaya pengendalian inflasi dan stabilisasi nilai tukar rupiah di tengah ketidakpastian ekonomi global. "Kebijakan moneter kami tetap pro-stability dengan tetap mendukung pertumbuhan ekonomi yang berkelanjutan," jelasnya.</p>
<blockquote>Catatan Redaksi: Keputusan ini menunjukkan sikap hati-hati BI di tengah tekanan pelemahan rupiah akibat penguatan dolar AS secara global. Pelaku pasar memperkirakan ruang penurunan suku bunga baru terbuka di kuartal kedua 2025.</blockquote>`,
    category: 'Ekonomi',
    image_url: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=450&fit=crop',
    source_name: 'CNBC',
    source_url: 'https://cnbc.com/4',
    created_at: '2025-01-14T14:00:00Z',
    updated_at: '2025-01-14T14:00:00Z',
    views: 12340
  },
  {
    id: 5,
    title: 'Startup Indonesia Kembangkan Satelit Nano untuk Pemantauan Pertanian Presisi',
    slug: 'startup-indonesia-kembangkan-satelit-nano-pertanian',
    summary: 'Sebuah startup teknologi asal Bandung berhasil mengembangkan satelit nano berukuran 10x10 cm yang mampu memantau kondisi lahan pertanian secara real-time.',
    content: `<p>Bandung — Sebuah startup teknologi asal Bandung berhasil mengembangkan satelit nano berukuran 10x10 sentimeter yang dirancang khusus untuk pemantauan pertanian presisi. Teknologi ini diharapkan mampu merevolusi sektor pertanian Indonesia.</p>
<h2>Poin Utama</h2>
<ul>
<li>Satelit nano berukuran 10x10 cm dengan bobot hanya 1,3 kg</li>
<li>Mampu memantau kelembaban tanah, kesehatan tanaman, dan cuaca mikro</li>
<li>Biaya peluncuran 90% lebih murah dibanding satelit konvensional</li>
<li>Uji coba orbit direncanakan pada Q3 2025</li>
</ul>
<p>CEO startup tersebut menjelaskan bahwa teknologi satelit nano ini memanfaatkan sensor multispektral canggih yang dapat mendeteksi kondisi tanaman dari orbit rendah bumi. Data yang dikumpulkan diolah untuk memberikan rekomendasi kepada petani.</p>
<p>"Petani Indonesia membutuhkan akses terhadap data yang akurat dan real-time. Kami ingin memberikan teknologi satelit yang terjangkau untuk meningkatkan produktivitas pertanian nasional," ungkapnya.</p>
<blockquote>Catatan Redaksi: Inovasi ini menunjukkan bahwa ekosistem startup deep-tech Indonesia mulai matang. Dukungan regulasi dan pendanaan tahap lanjut akan menentukan keberhasilan komersialisasi teknologi ini.</blockquote>`,
    category: 'Teknologi',
    image_url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&h=450&fit=crop',
    source_name: 'Tribun',
    source_url: 'https://tribun.com/5',
    created_at: '2025-01-14T10:30:00Z',
    updated_at: '2025-01-14T10:30:00Z',
    views: 8750
  },
  {
    id: 6,
    title: 'Presiden Teken Perpres Percepatan Pembangunan IKN: Target 2028 Operasional Penuh',
    slug: 'presiden-teken-perpres-percepatan-ikn-2028',
    summary: 'Presiden menandatangani Peraturan Presiden baru yang mempercepat timeline pembangunan Ibu Kota Nusantara dengan target operasional penuh pada 2028.',
    content: `<p>Jakarta — Presiden Republik Indonesia telah menandatangani Peraturan Presiden (Perpres) baru terkait percepatan pembangunan Ibu Kota Nusantara (IKN). Perpres ini menetapkan target operasional penuh IKN pada tahun 2028.</p>
<h2>Poin Utama</h2>
<ul>
<li>Perpres baru menetapkan target operasional penuh IKN pada 2028</li>
<li>Alokasi anggaran tambahan sebesar Rp45 triliun untuk infrastruktur kritis</li>
<li>Pemindahan ASN tahap pertama dimulai semester II 2025</li>
<li>Investor asing dari 8 negara sudah berkomitmen investasi</li>
</ul>
<p>Kepala Otorita IKN menyatakan bahwa progres pembangunan telah mencapai 42% untuk infrastruktur inti, termasuk Istana Negara, gedung-gedung kementerian, serta jaringan transportasi dasar.</p>
<blockquote>Catatan Redaksi: Percepatan pembangunan IKN memerlukan transparansi anggaran yang ketat dan pengawasan independen untuk memastikan proyek ini berjalan sesuai rencana tanpa pembengkakan biaya.</blockquote>`,
    category: 'Nasional',
    image_url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=450&fit=crop',
    source_name: 'Antara',
    source_url: 'https://antara.go.id/6',
    created_at: '2025-01-14T09:00:00Z',
    updated_at: '2025-01-14T09:00:00Z',
    views: 31500
  },
  {
    id: 7,
    title: 'Konflik di Laut China Selatan Memanas: ASEAN Serukan Dialog Multilateral',
    slug: 'konflik-laut-china-selatan-asean-dialog',
    summary: 'Ketegangan di Laut China Selatan kembali memanas setelah insiden maritim terbaru. ASEAN mengeluarkan pernyataan bersama yang menyerukan dialog multilateral.',
    content: `<p>Jakarta — Ketegangan di kawasan Laut China Selatan kembali meningkat menyusul serangkaian insiden maritim terbaru yang melibatkan beberapa negara klaim. Perhimpunan Bangsa-Bangsa Asia Tenggara (ASEAN) mengeluarkan pernyataan bersama yang menyerukan dialog multilateral.</p>
<h2>Poin Utama</h2>
<ul>
<li>Insiden maritim terbaru terjadi di perairan Kepulauan Spratly</li>
<li>ASEAN serukan de-eskalasi dan dialog berbasis hukum internasional</li>
<li>Indonesia tegaskan posisi sebagai honest broker</li>
<li>Negosiasi Code of Conduct (COC) dipercepat</li>
</ul>
<p>Menteri Luar Negeri Indonesia menegaskan bahwa Indonesia akan terus memainkan peran sebagai mediator yang jujur dalam perselisihan di Laut China Selatan. "Indonesia mendorong penyelesaian damai yang berbasis hukum internasional, khususnya UNCLOS 1982," ujarnya.</p>
<blockquote>Catatan Redaksi: Dinamika geopolitik di Laut China Selatan tetap menjadi ancaman signifikan bagi stabilitas kawasan. Diplomasi ASEAN perlu diperkuat agar Code of Conduct dapat segera dirampungkan.</blockquote>`,
    category: 'Internasional',
    image_url: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&h=450&fit=crop',
    source_name: 'Tempo',
    source_url: 'https://tempo.co/7',
    created_at: '2025-01-14T07:45:00Z',
    updated_at: '2025-01-14T07:45:00Z',
    views: 19200
  },
  {
    id: 8,
    title: 'MA Putuskan Judicial Review UU Cipta Kerja: Sejumlah Pasal Inkonstitusional',
    slug: 'ma-judicial-review-uu-cipta-kerja-inkonstitusional',
    summary: 'Mahkamah Agung mengabulkan sebagian permohonan judicial review terhadap Undang-Undang Cipta Kerja, menyatakan beberapa pasal tidak sesuai konstitusi.',
    content: `<p>Jakarta — Mahkamah Agung (MA) telah mengabulkan sebagian permohonan judicial review terhadap Undang-Undang Cipta Kerja. Dalam putusan yang dibacakan hari ini, MA menyatakan beberapa pasal dalam UU tersebut bertentangan dengan Undang-Undang Dasar 1945.</p>
<h2>Poin Utama</h2>
<ul>
<li>Tujuh pasal dinyatakan inkonstitusional dan tidak memiliki kekuatan hukum mengikat</li>
<li>Pasal terkait pesangon dan kontrak kerja menjadi sorotan utama</li>
<li>Pemerintah diberi waktu 2 tahun untuk melakukan revisi</li>
<li>Serikat pekerja sambut positif putusan ini</li>
</ul>
<p>Putusan ini disambut positif oleh kalangan serikat pekerja dan buruh yang selama ini menolak beberapa ketentuan dalam UU Cipta Kerja yang dianggap merugikan hak-hak pekerja.</p>
<blockquote>Catatan Redaksi: Putusan MA ini menunjukkan pentingnya mekanisme checks and balances dalam sistem ketatanegaraan Indonesia. Proses revisi perlu dilakukan secara partisipatif dengan melibatkan semua pemangku kepentingan.</blockquote>`,
    category: 'Hukum',
    image_url: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=450&fit=crop',
    source_name: 'Detik',
    source_url: 'https://detik.com/8',
    created_at: '2025-01-13T16:00:00Z',
    updated_at: '2025-01-13T16:00:00Z',
    views: 27800
  },
  {
    id: 9,
    title: 'Tren Wisata Berkelanjutan: Pulau Komodo Terapkan Kuota Pengunjung Ketat',
    slug: 'wisata-berkelanjutan-pulau-komodo-kuota-pengunjung',
    summary: 'Otoritas Taman Nasional Komodo menerapkan sistem kuota pengunjung yang lebih ketat untuk melindungi ekosistem unik dan populasi Komodo.',
    content: `<p>Labuan Bajo — Otoritas Taman Nasional Komodo resmi menerapkan sistem kuota pengunjung yang lebih ketat mulai Februari 2025. Kebijakan ini bertujuan melindungi ekosistem unik dan populasi Komodo yang semakin terancam akibat overtourism.</p>
<h2>Poin Utama</h2>
<ul>
<li>Kuota pengunjung dibatasi maksimal 200 orang per hari per pulau</li>
<li>Sistem reservasi online wajib minimal 14 hari sebelum kunjungan</li>
<li>Tiket masuk dinaikkan menjadi Rp750.000 untuk wisatawan domestik</li>
<li>Program edukasi konservasi menjadi bagian wajib kunjungan</li>
</ul>
<p>Kepala Balai Taman Nasional Komodo menjelaskan bahwa kebijakan ini merupakan langkah penting dalam menjaga keseimbangan antara pemanfaatan wisata dan kelestarian alam.</p>
<blockquote>Catatan Redaksi: Wisata berkelanjutan bukan sekadar tren global, melainkan kebutuhan mendesak untuk warisan alam Indonesia yang tak ternilai. Model kuota Komodo bisa menjadi acuan bagi destinasi wisata alam lainnya.</blockquote>`,
    category: 'Gaya Hidup',
    image_url: 'https://images.unsplash.com/photo-1518709766631-a6a7f45921c3?w=800&h=450&fit=crop',
    source_name: 'CNBC',
    source_url: 'https://cnbc.com/9',
    created_at: '2025-01-13T11:30:00Z',
    updated_at: '2025-01-13T11:30:00Z',
    views: 14600
  },
  {
    id: 10,
    title: 'Indonesia Perkuat Pertahanan Siber Nasional: Bentuk Badan Siber Khusus',
    slug: 'indonesia-perkuat-pertahanan-siber-nasional',
    summary: 'Pemerintah membentuk badan keamanan siber khusus yang langsung bertanggung jawab kepada Presiden untuk menghadapi ancaman siber yang semakin kompleks.',
    content: `<p>Jakarta — Pemerintah Indonesia resmi membentuk badan keamanan siber khusus yang langsung bertanggung jawab kepada Presiden. Badan ini akan mengoordinasikan seluruh upaya pertahanan siber nasional menghadapi ancaman yang semakin kompleks.</p>
<h2>Poin Utama</h2>
<ul>
<li>Badan baru langsung di bawah Presiden dengan anggaran Rp8 triliun</li>
<li>Rekrutmen 500 talenta keamanan siber dari universitas terbaik</li>
<li>Pusat operasi keamanan siber 24/7 akan beroperasi mulai April 2025</li>
<li>Kerja sama dengan Five Eyes dan negara-negara ASEAN</li>
</ul>
<p>Kepala badan yang baru ditunjuk menyatakan bahwa Indonesia menghadapi rata-rata 1,2 miliar serangan siber per tahun, dan angka ini terus meningkat. "Keamanan siber adalah keamanan nasional di era digital," tegasnya.</p>
<blockquote>Catatan Redaksi: Pembentukan badan siber khusus ini merupakan langkah yang sudah lama dinantikan. Namun, efektivitasnya akan bergantung pada independensi operasional dan kecukupan sumber daya manusia berkualitas.</blockquote>`,
    category: 'Teknologi',
    image_url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=450&fit=crop',
    source_name: 'Tribun',
    source_url: 'https://tribun.com/10',
    created_at: '2025-01-13T09:00:00Z',
    updated_at: '2025-01-13T09:00:00Z',
    views: 21300
  },
  {
    id: 11,
    title: 'Timnas Indonesia U-23 Lolos ke Semifinal Piala Asia: Kalahkan Korea Selatan',
    slug: 'timnas-u23-lolos-semifinal-piala-asia',
    summary: 'Timnas Indonesia U-23 menciptakan sejarah dengan mengalahkan Korea Selatan 2-1 di perempat final Piala Asia U-23 untuk melaju ke semifinal.',
    content: `<p>Doha — Timnas Indonesia U-23 menciptakan sejarah baru dalam sepak bola Indonesia dengan mengalahkan Korea Selatan 2-1 di babak perempat final Piala Asia U-23 2025. Kemenangan ini membawa Garuda Muda melaju ke semifinal.</p>
<h2>Poin Utama</h2>
<ul>
<li>Indonesia menang 2-1 atas Korea Selatan di perempat final</li>
<li>Gol dicetak oleh dua pemain naturalisasi di menit 67 dan 82</li>
<li>Indonesia akan menghadapi Jepang di semifinal</li>
<li>Ini pencapaian terbaik Indonesia di Piala Asia U-23</li>
</ul>
<p>Pelatih Timnas memuji kekompakan dan mentalitas juara para pemainnya. "Mereka bermain dengan hati, dengan keberanian. Ini bukan keberuntungan, ini hasil kerja keras," ungkapnya penuh emosi.</p>
<blockquote>Catatan Redaksi: Prestasi bersejarah ini membuktikan bahwa investasi dalam pembinaan sepak bola usia muda mulai membuahkan hasil. Keberlanjutan program ini harus dijaga lintas pergantian kepengurusan.</blockquote>`,
    category: 'Olahraga',
    image_url: 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=800&h=450&fit=crop',
    source_name: 'Detik',
    source_url: 'https://detik.com/11',
    created_at: '2025-01-13T05:30:00Z',
    updated_at: '2025-01-13T05:30:00Z',
    views: 89000
  },
  {
    id: 12,
    title: 'Inflasi Januari 2025 Terkendali di 2,8%: Harga Pangan Stabil Pasca Nataru',
    slug: 'inflasi-januari-2025-terkendali-harga-pangan-stabil',
    summary: 'Badan Pusat Statistik melaporkan inflasi Januari 2025 tercatat sebesar 2,8% secara tahunan, didukung stabilnya harga bahan pangan pasca periode Natal dan Tahun Baru.',
    content: `<p>Jakarta — Badan Pusat Statistik (BPS) melaporkan bahwa inflasi pada Januari 2025 tercatat sebesar 2,8% secara tahunan (year-on-year). Angka ini masih berada dalam koridor target Bank Indonesia sebesar 2,5%±1%.</p>
<h2>Poin Utama</h2>
<ul>
<li>Inflasi tahunan Januari 2025 sebesar 2,8%</li>
<li>Inflasi bulanan (month-to-month) sebesar 0,42%</li>
<li>Harga beras dan cabai menunjukkan tren penurunan</li>
<li>Transportasi dan akomodasi menyumbang inflasi tertinggi</li>
</ul>
<p>Kepala BPS menjelaskan bahwa stabilnya harga pangan menjadi faktor utama terkendalinya inflasi Januari. "Operasi pasar yang dilakukan pemerintah efektif menjaga ketersediaan dan harga bahan pokok," jelasnya.</p>
<blockquote>Catatan Redaksi: Terkendalinya inflasi Januari memberikan ruang bagi Bank Indonesia untuk mempertimbangkan pelonggaran kebijakan moneter di kuartal mendatang, meski volatilitas global tetap menjadi faktor risiko.</blockquote>`,
    category: 'Ekonomi',
    image_url: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=450&fit=crop',
    source_name: 'CNBC',
    source_url: 'https://cnbc.com/12',
    created_at: '2025-01-12T13:00:00Z',
    updated_at: '2025-01-12T13:00:00Z',
    views: 9800
  },
  {
    id: 13,
    title: 'Gempa M6.2 Guncang Sulawesi Tengah: BNPB Kerahkan Tim Respons Cepat',
    slug: 'gempa-sulawesi-tengah-bnpb-respons-cepat',
    summary: 'Gempa bumi berkekuatan M6.2 mengguncang wilayah Sulawesi Tengah. BNPB langsung mengerahkan tim respons cepat dan mendirikan posko pengungsian.',
    content: `<p>Palu — Gempa bumi berkekuatan Magnitudo 6.2 mengguncang wilayah Sulawesi Tengah pada dini hari tadi. Badan Nasional Penanggulangan Bencana (BNPB) langsung mengerahkan tim respons cepat ke lokasi terdampak.</p>
<h2>Poin Utama</h2>
<ul>
<li>Gempa M6.2 terjadi pada pukul 02.17 WITA dengan kedalaman 10 km</li>
<li>Epicentrum berada 35 km tenggara Palu</li>
<li>BNPB mendirikan 15 posko pengungsian</li>
<li>Tidak ada peringatan tsunami</li>
</ul>
<p>Kepala BNPB menyatakan bahwa tim telah berada di lokasi dan melakukan asesmen cepat terhadap kerusakan. "Prioritas utama kami adalah keselamatan warga dan pemenuhan kebutuhan dasar pengungsi," tegasnya.</p>
<blockquote>Catatan Redaksi: Kejadian ini kembali mengingatkan pentingnya kesiapsiagaan bencana di wilayah-wilayah rawan gempa. Edukasi mitigasi bencana harus menjadi program berkelanjutan di daerah-daerah sepanjang Cincin Api Pasifik.</blockquote>`,
    category: 'Nasional',
    image_url: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?w=800&h=450&fit=crop',
    source_name: 'Antara',
    source_url: 'https://antara.go.id/13',
    created_at: '2025-01-12T04:00:00Z',
    updated_at: '2025-01-12T04:00:00Z',
    views: 42000
  },
  {
    id: 14,
    title: 'DPR Sahkan RUU Perlindungan Data Pribadi Versi Final: Sanksi Tegas Pelanggar',
    slug: 'dpr-sahkan-ruu-perlindungan-data-pribadi-final',
    summary: 'DPR mengesahkan versi final RUU Perlindungan Data Pribadi dengan sanksi pidana bagi pelanggar hingga 6 tahun penjara dan denda Rp6 miliar.',
    content: `<p>Jakarta — Dewan Perwakilan Rakyat (DPR) Republik Indonesia telah mengesahkan versi final Rancangan Undang-Undang Perlindungan Data Pribadi. UU ini memuat sanksi tegas bagi pelanggar, termasuk pidana penjara hingga 6 tahun dan denda maksimal Rp6 miliar.</p>
<h2>Poin Utama</h2>
<ul>
<li>UU berlaku efektif 6 bulan setelah diundangkan</li>
<li>Sanksi pidana maksimal 6 tahun penjara dan denda Rp6 miliar</li>
<li>Pembentukan Lembaga Pengawas Data Pribadi independen</li>
<li>Wajib consent eksplisit untuk pengumpulan data pribadi</li>
</ul>
<p>Ketua Komisi I DPR menyatakan bahwa pengesahan UU ini merupakan tonggak penting dalam perlindungan hak-hak digital warga negara Indonesia.</p>
<blockquote>Catatan Redaksi: Pengesahan UU PDP versi final ini patut diapresiasi. Kunci keberhasilannya terletak pada pembentukan lembaga pengawas yang benar-benar independen dan memiliki kapasitas penegakan yang memadai.</blockquote>`,
    category: 'Hukum',
    image_url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop',
    source_name: 'Tempo',
    source_url: 'https://tempo.co/14',
    created_at: '2025-01-11T15:00:00Z',
    updated_at: '2025-01-11T15:00:00Z',
    views: 18900
  },
  {
    id: 15,
    title: 'WHO Tetapkan Status Darurat Kesehatan Global Terkait Wabah Baru di Afrika Barat',
    slug: 'who-darurat-kesehatan-global-wabah-afrika-barat',
    summary: 'Organisasi Kesehatan Dunia menetapkan status darurat kesehatan global menyusul wabah penyakit menular baru yang merebak di beberapa negara Afrika Barat.',
    content: `<p>Jenewa — Organisasi Kesehatan Dunia (WHO) telah menetapkan status darurat kesehatan masyarakat yang menjadi perhatian internasional (PHEIC) terkait wabah penyakit menular baru yang merebak di beberapa negara Afrika Barat.</p>
<h2>Poin Utama</h2>
<ul>
<li>WHO tetapkan PHEIC untuk wabah di Afrika Barat</li>
<li>Tiga negara melaporkan kasus: Guinea, Sierra Leone, dan Liberia</li>
<li>Kemenkes RI tingkatkan pengawasan di pintu masuk negara</li>
<li>Indonesia belum melaporkan kasus terkait</li>
</ul>
<p>Kementerian Kesehatan Indonesia langsung merespons dengan meningkatkan pengawasan di seluruh pintu masuk negara, termasuk bandara dan pelabuhan internasional.</p>
<blockquote>Catatan Redaksi: Penetapan status PHEIC oleh WHO harus ditanggapi serius tanpa panik berlebihan. Protokol kesehatan di pintu masuk negara dan kesiapan fasilitas isolasi perlu segera divalidasi ulang.</blockquote>`,
    category: 'Internasional',
    image_url: 'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?w=800&h=450&fit=crop',
    source_name: 'Antara',
    source_url: 'https://antara.go.id/15',
    created_at: '2025-01-11T10:00:00Z',
    updated_at: '2025-01-11T10:00:00Z',
    views: 35400
  },
  {
    id: 16,
    title: 'Era Kendaraan Listrik: Pabrik Baterai Terbesar Asia Tenggara Diresmikan di Karawang',
    slug: 'pabrik-baterai-terbesar-asia-tenggara-karawang',
    summary: 'Pabrik baterai kendaraan listrik terbesar di Asia Tenggara resmi beroperasi di Karawang, Jawa Barat, dengan kapasitas produksi 10 GWh per tahun.',
    content: `<p>Karawang — Pabrik baterai kendaraan listrik terbesar di Asia Tenggara resmi beroperasi di Karawang, Jawa Barat. Fasilitas ini memiliki kapasitas produksi 10 Gigawatt-hour (GWh) per tahun dan menyerap 3.000 tenaga kerja lokal.</p>
<h2>Poin Utama</h2>
<ul>
<li>Kapasitas produksi 10 GWh per tahun, terbesar di ASEAN</li>
<li>Investasi senilai USD 1,1 miliar dari konsorsium internasional</li>
<li>Menyerap 3.000 tenaga kerja langsung</li>
<li>Produksi untuk pasar domestik dan ekspor ke ASEAN</li>
</ul>
<p>Menteri Perindustrian menyatakan bahwa pabrik ini menempatkan Indonesia sebagai pusat rantai pasok kendaraan listrik di kawasan Asia Tenggara.</p>
<blockquote>Catatan Redaksi: Kehadiran pabrik baterai ini merupakan bukti konkret potensi Indonesia dalam ekosistem kendaraan listrik global. Kesiapan infrastruktur pengisian daya menjadi tantangan berikutnya yang harus diatasi.</blockquote>`,
    category: 'Ekonomi',
    image_url: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&h=450&fit=crop',
    source_name: 'CNBC',
    source_url: 'https://cnbc.com/16',
    created_at: '2025-01-11T08:00:00Z',
    updated_at: '2025-01-11T08:00:00Z',
    views: 16700
  }
];

export function getArticleBySlug(slug: string): Article | undefined {
  return articles.find(a => a.slug === slug);
}

export function getArticlesByCategory(category: string): Article[] {
  return articles.filter(a => a.category.toLowerCase() === category.toLowerCase());
}

export function getRelatedArticles(article: Article, limit = 4): Article[] {
  return articles
    .filter(a => a.id !== article.id && a.category === article.category)
    .slice(0, limit);
}

export function getBreakingNews(): Article[] {
  return articles.slice(0, 5);
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}, ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')} WIB`;
}

export function formatViews(n: number): string {
  if (n >= 1000) return (n/1000).toFixed(1).replace('.0','') + 'rb';
  return String(n);
}

export function getCategoryColor(category: string): string {
  const colors: Record<string,string> = {
    'Nasional': 'bg-red-700',
    'Politik': 'bg-blue-700',
    'Ekonomi': 'bg-emerald-700',
    'Teknologi': 'bg-violet-700',
    'Olahraga': 'bg-orange-600',
    'Internasional': 'bg-sky-700',
    'Gaya Hidup': 'bg-pink-600',
    'Hukum': 'bg-amber-700',
  };
  return colors[category] || 'bg-gray-700';
}
