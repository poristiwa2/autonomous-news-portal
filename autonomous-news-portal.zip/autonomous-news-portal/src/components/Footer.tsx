import { Link } from 'react-router-dom';
import { CATEGORIES } from '@/data/mockArticles';

export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-white mt-16">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-700 rounded-lg flex items-center justify-center text-white font-serif font-black text-xl">
                P
              </div>
              <div>
                <h2 className="font-serif text-xl font-black text-white leading-none">
                  Poristiwa<span className="text-red-400">.my.id</span>
                </h2>
                <p className="text-[9px] text-neutral-500 tracking-[0.2em] uppercase mt-0.5">
                  Nadi Peristiwa, Detak Digital
                </p>
              </div>
            </Link>
            <p className="text-sm text-neutral-400 leading-relaxed mt-4">
              Portal berita terkini dan terpercaya Indonesia. Menyajikan informasi akurat dari redaksi profesional Poristiwa Media Group.
            </p>
            <div className="mt-4 text-xs text-neutral-500">
              <p>Poristiwa Media Group</p>
              <p>Jakarta, Indonesia</p>
            </div>
          </div>

          {/* Kategori */}
          <div>
            <h3 className="font-serif font-bold text-lg mb-4 text-white">Kategori</h3>
            <ul className="space-y-2">
              {CATEGORIES.map(cat => (
                <li key={cat}>
                  <Link
                    to={`/category/${cat.toLowerCase().replace(' ','-')}`}
                    className="text-sm text-neutral-400 hover:text-red-400 transition-colors"
                  >
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Perusahaan */}
          <div>
            <h3 className="font-serif font-bold text-lg mb-4 text-white">Perusahaan</h3>
            <ul className="space-y-2">
              <li><Link to="/pedoman-media-siber" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Pedoman Media Siber</Link></li>
              <li><Link to="/pasang-iklan" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Pasang Iklan</Link></li>
              <li><a href="#" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Tentang Kami</a></li>
              <li><a href="#" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Redaksi</a></li>
              <li><a href="#" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Kebijakan Privasi</a></li>
              <li><a href="#" className="text-sm text-neutral-400 hover:text-red-400 transition-colors">Syarat &amp; Ketentuan</a></li>
            </ul>
          </div>

          {/* Kontak */}
          <div>
            <h3 className="font-serif font-bold text-lg mb-4 text-white">Hubungi Redaksi</h3>
            <ul className="space-y-3 text-sm text-neutral-400">
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">&#9993;</span>
                <span>redaksi@poristiwa.my.id</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">&#9742;</span>
                <span>+62 21 5050 1234</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 mt-0.5">&#9678;</span>
                <span>Gedung Poristiwa Media, Lt. 12<br/>Jl. Gatot Subroto Kav. 36-38<br/>Jakarta Selatan 12190</span>
              </li>
            </ul>
            <div className="flex gap-3 mt-4">
              {['X','FB','IG','YT'].map(social => (
                <a
                  key={social}
                  href="#"
                  className="w-8 h-8 rounded-md bg-neutral-800 flex items-center justify-center text-xs font-bold text-neutral-400 hover:bg-red-700 hover:text-white transition-all"
                >
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-xs text-neutral-500">
            &copy; {new Date().getFullYear()} Poristiwa Media Group. Seluruh hak cipta dilindungi undang-undang.
          </p>
          <p className="text-xs text-neutral-500">
            Anggota Dewan Pers Indonesia &bull; Terverifikasi Faktual
          </p>
        </div>
      </div>
    </footer>
  );
}
