import { Link } from 'react-router-dom';
import { Clock, Eye } from 'lucide-react';
import { type Article, formatDate, formatViews, getCategoryColor } from '@/data/mockArticles';

interface NewsCardProps {
  article: Article;
  variant?: 'default' | 'hero' | 'horizontal' | 'compact';
}

export default function NewsCard({ article, variant = 'default' }: NewsCardProps) {
  const catColor = getCategoryColor(article.category);

  if (variant === 'hero') {
    return (
      <Link to={`/news/${article.slug}`} className="group block relative rounded-2xl overflow-hidden shadow-xl">
        <div className="aspect-[16/9] md:aspect-[21/9]">
          <img
            src={article.image_url}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            loading="eager"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
          <span className={`inline-block px-3 py-1 text-xs font-bold text-white rounded-md ${catColor} mb-3 uppercase tracking-wider`}>
            {article.category}
          </span>
          <h2 className="font-serif text-2xl md:text-4xl lg:text-5xl font-black text-white leading-tight mb-3 group-hover:text-red-300 transition-colors">
            {article.title}
          </h2>
          <p className="text-white/70 text-sm md:text-base line-clamp-2 max-w-3xl mb-4">
            {article.summary}
          </p>
          <div className="flex items-center gap-4 text-xs text-white/50">
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {formatDate(article.created_at)}
            </span>
            <span className="flex items-center gap-1">
              <Eye size={12} />
              {formatViews(article.views)} dilihat
            </span>
            <span className="text-white/40">|</span>
            <span className="text-red-400 font-medium">{article.source_name}</span>
          </div>
        </div>
      </Link>
    );
  }

  if (variant === 'horizontal') {
    return (
      <Link to={`/news/${article.slug}`} className="group flex gap-4 glass-card rounded-xl p-3 hover:shadow-lg transition-all duration-300">
        <div className="flex-shrink-0 w-28 h-20 md:w-36 md:h-24 rounded-lg overflow-hidden">
          <img
            src={article.image_url}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        </div>
        <div className="flex-1 min-w-0 flex flex-col justify-between">
          <div>
            <span className={`inline-block px-2 py-0.5 text-[10px] font-bold text-white rounded ${catColor} mb-1.5 uppercase tracking-wider`}>
              {article.category}
            </span>
            <h3 className="font-serif text-sm md:text-base font-bold text-gray-900 leading-snug line-clamp-2 group-hover:text-red-700 transition-colors">
              {article.title}
            </h3>
          </div>
          <div className="flex items-center gap-3 text-[10px] text-gray-400 mt-1">
            <span className="flex items-center gap-1">
              <Clock size={10} />
              {formatDate(article.created_at).split(',')[0]}
            </span>
            <span className="flex items-center gap-1">
              <Eye size={10} />
              {formatViews(article.views)}
            </span>
          </div>
        </div>
      </Link>
    );
  }

  if (variant === 'compact') {
    return (
      <Link to={`/news/${article.slug}`} className="group flex items-start gap-3 py-3 border-b border-gray-100 last:border-0">
        <span className="flex-shrink-0 w-8 h-8 rounded-full bg-red-50 text-red-700 text-xs font-bold flex items-center justify-center">
          {formatViews(article.views)}
        </span>
        <div className="flex-1">
          <h4 className="text-sm font-semibold text-gray-800 leading-snug line-clamp-2 group-hover:text-red-700 transition-colors">
            {article.title}
          </h4>
          <span className="text-[10px] text-gray-400 mt-1 inline-block">{article.category}</span>
        </div>
      </Link>
    );
  }

  // Default card
  return (
    <Link to={`/news/${article.slug}`} className="group block glass-card rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div className="aspect-[16/10] overflow-hidden">
        <img
          src={article.image_url}
          alt={article.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          loading="lazy"
        />
      </div>
      <div className="p-4 md:p-5">
        <div className="flex items-center justify-between mb-2.5">
          <span className={`inline-block px-2.5 py-0.5 text-[10px] font-bold text-white rounded-md ${catColor} uppercase tracking-wider category-badge`}>
            {article.category}
          </span>
          <span className="text-[10px] text-gray-400 font-medium">{article.source_name}</span>
        </div>
        <h3 className="font-serif text-base md:text-lg font-bold text-gray-900 leading-snug line-clamp-3 group-hover:text-red-700 transition-colors mb-2">
          {article.title}
        </h3>
        <p className="text-sm text-gray-500 line-clamp-2 mb-3 leading-relaxed">
          {article.summary}
        </p>
        <div className="flex items-center gap-3 text-[11px] text-gray-400">
          <span className="flex items-center gap-1">
            <Clock size={11} />
            {formatDate(article.created_at).split(',')[0]}
          </span>
          <span className="flex items-center gap-1">
            <Eye size={11} />
            {formatViews(article.views)} dilihat
          </span>
        </div>
      </div>
    </Link>
  );
}
