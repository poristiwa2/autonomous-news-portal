interface AdSlotProps {
  type: 'banner' | 'rectangle' | 'leaderboard';
  className?: string;
}

export default function AdSlot({ type, className = '' }: AdSlotProps) {
  const dimensions: Record<string, { ratio: string; maxW: string; label: string }> = {
    banner: { ratio: 'aspect-[728/90]', maxW: 'max-w-[728px]', label: '728×90' },
    rectangle: { ratio: 'aspect-[300/250]', maxW: 'max-w-[300px]', label: '300×250' },
    leaderboard: { ratio: 'aspect-[970/90]', maxW: 'max-w-[970px]', label: '970×90' },
  };

  const dim = dimensions[type];

  return (
    <div className={`mx-auto ${dim.maxW} ${className}`}>
      <div className={`${dim.ratio} w-full bg-gradient-to-br from-gray-50 to-gray-100 border border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center`}>
        <span className="text-[10px] text-gray-300 font-medium uppercase tracking-widest">Iklan {dim.label}</span>
      </div>
    </div>
  );
}
