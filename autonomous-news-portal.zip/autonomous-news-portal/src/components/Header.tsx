import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Search, TrendingUp, ChevronRight } from 'lucide-react';
import { getBreakingNews, CATEGORIES } from '@/data/mockArticles';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const breaking = getBreakingNews();

  const now = new Date();
  const days = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
  const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  const dateStr = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;

  return (
    <header className="sticky top-0 z-50">
      {/* Breaking News Ticker */}
      <div className="bg-red-950 text-white overflow-hidden">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-red-600 px-4 py-1.5 flex items-center gap-1.5 font-semibold text-xs uppercase tracking-wider z-10">
            <TrendingUp size={14} />
            <span>Terkini</span>
          </div>
          <div className="overflow-hidden flex-1 py-1.5">
            <div className="marquee-animate whitespace-nowrap">
              {breaking.map((a, i) => (
                <Link
                  key={a.id}
                  to={`/news/${a.slug}`}
                  className="inline-block text-sm text-white/90 hover:text-white mx-8 transition-colors"
                >
                  <span className="text-red-400 font-bold mr-2">{'\u25CF'}</span>
                  {a.title}
                  {i < breaking.length - 1 && <span className="ml-8 text-white/30">|</span>}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          {/* Top bar with date */}
          <div className="flex items-center justify-between py-2 border-b border-gray-100 text-xs text-gray-400">
            <span>{dateStr}</span>
            <div className="flex items-center gap-4">
              <Link to="/pedoman-media-siber" className="hover:text-red-700 transition-colors">Pedoman Media Siber</Link>
              <Link to="/pasang-iklan" className="hover:text-red-700 transition-colors">Pasang Iklan</Link>
            </div>
          </div>

          {/* Logo & Navigation */}
          <div className="flex items-center justify-between py-4">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-red-700 rounded-lg flex items-center justify-center text-white font-serif font-black text-xl shadow-md group-hover:bg-red-800 transition-colors">
                P
              </div>
              <div>
                <h1 className="font-serif text-2xl font-black text-gray-900 tracking-tight leading-none">
                  Poristiwa<span className="text-red-700">.my.id</span>
                </h1>
                <p className="text-[10px] text-gray-400 tracking-[0.2em] uppercase font-medium mt-0.5">
                  Nadi Peristiwa, Detak Digital
                </p>
              </div>
            </Link>

            <div className="hidden lg:flex items-center gap-1">
              {CATEGORIES.slice(0, 7).map(cat => (
                <Link
                  key={cat}
                  to={`/category/${cat.toLowerCase().replace(' ','-')}`}
                  className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-all"
                >
                  {cat}
                </Link>
              ))}
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="ml-2 p-2 text-gray-400 hover:text-red-700 hover:bg-red-50 rounded-md transition-all"
              >
                <Search size={18} />
              </button>
            </div>

            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden p-2 text-gray-600 hover:text-red-700"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="border-t border-gray-100 bg-gray-50 py-3 px-4">
            <div className="max-w-2xl mx-auto relative">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Cari berita terkini..."
                className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 bg-white text-sm focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100 transition-all"
                autoFocus
              />
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="lg:hidden border-t border-gray-100 bg-white">
            <div className="py-2 px-4">
              {CATEGORIES.map(cat => (
                <Link
                  key={cat}
                  to={`/category/${cat.toLowerCase().replace(' ','-')}`}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center justify-between py-3 px-2 text-sm font-medium text-gray-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-all"
                >
                  <span>{cat}</span>
                  <ChevronRight size={16} className="text-gray-300" />
                </Link>
              ))}
              <div className="border-t border-gray-100 mt-2 pt-2">
                <Link
                  to="/pedoman-media-siber"
                  onClick={() => setMenuOpen(false)}
                  className="block py-3 px-2 text-sm text-gray-400 hover:text-red-700"
                >
                  Pedoman Media Siber
                </Link>
                <Link
                  to="/pasang-iklan"
                  onClick={() => setMenuOpen(false)}
                  className="block py-3 px-2 text-sm text-gray-400 hover:text-red-700"
                >
                  Pasang Iklan
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
