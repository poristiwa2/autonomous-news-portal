import { Link } from 'react-router-dom';
import { ChevronRight, Shield } from 'lucide-react';

export default function PedomanMediaSiber() {
  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-xs text-gray-400">
            <Link to="/" className="hover:text-red-700 transition-colors">Beranda</Link>
            <ChevronRight size={12} />
            <span className="text-gray-600">Pedoman Media Siber</span>
          </nav>
        </div>
      </div>

      {/* Header */}
      <div className="bg-neutral-900 text-white">
        <div className="max-w-4xl mx-auto px-4 py-12 text-center">
          <Shield size={48} className="text-red-400 mx-auto mb-4" />
          <h1 className="font-serif text-3xl md:text-4xl font-black mb-3">Pedoman Pemberitaan Media Siber</h1>
          <p className="text-white/60 text-sm">
            Berdasarkan Peraturan Dewan Pers Nomor: 1/Peraturan-DP/III/2012
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-10">
        <div className="glass-card rounded-2xl p-6 md:p-10">
          <div className="max-w-none">
            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Kemerdekaan Pers dan Pemberitaan
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed mb-3">
                Poristiwa.my.id menjunjung tinggi kemerdekaan pers sebagaimana diamanatkan dalam Undang-Undang Nomor 40 Tahun 1999 tentang Pers. Dalam menjalankan fungsi jurnalistik, redaksi Poristiwa Media Group berpegang pada prinsip-prinsip jurnalisme yang bertanggung jawab, akurat, dan berimbang.
              </p>
              <p className="text-sm text-gray-600 leading-relaxed">
                Media siber memiliki karakter khusus sehingga memerlukan pedoman agar pengelolaannya dapat dilaksanakan secara profesional, memenuhi fungsi, hak, dan kewajibannya sesuai dengan Undang-Undang Nomor 40 Tahun 1999 tentang Pers dan Kode Etik Jurnalistik.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Verifikasi dan Keberimbangan Berita
              </h2>
              <ol className="text-sm text-gray-600 leading-relaxed space-y-2 list-decimal pl-5">
                <li>Pada prinsipnya setiap berita harus melalui verifikasi.</li>
                <li>Berita yang dapat merugikan pihak lain memerlukan verifikasi pada berita yang sama untuk memenuhi prinsip akurasi dan keberimbangan.</li>
                <li>Ketentuan pada butir (a) di atas dikecualikan, dengan syarat: berita benar-benar mengandung kepentingan publik yang bersifat mendesak; sumber berita yang pertama adalah sumber yang jelas disebutkan identitasnya, kredibel, dan kompeten; subjek berita yang harus dikonfirmasi tidak diketahui keberadaannya dan/atau tidak dapat diwawancarai; media memberikan penjelasan kepada pembaca bahwa berita tersebut masih memerlukan verifikasi lebih lanjut yang diupayakan dalam waktu secepatnya.</li>
              </ol>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Isi Buatan Pengguna (User Generated Content)
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed mb-3">
                Media siber wajib mencantumkan syarat dan ketentuan mengenai isi buatan pengguna yang tidak bertentangan dengan Undang-Undang No. 40 tahun 1999 tentang Pers dan Kode Etik Jurnalistik, yang ditempatkan secara jelas dan mudah diakses oleh pengguna.
              </p>
              <p className="text-sm text-gray-600 leading-relaxed">
                Poristiwa.my.id menyediakan mekanisme pengaduan isi buatan pengguna yang dinilai melanggar ketentuan. Media siber wajib menyunting, menghapus, dan melakukan tindakan koreksi setiap isi buatan pengguna yang dilaporkan dan melanggar ketentuan.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Ralat, Koreksi, dan Hak Jawab
              </h2>
              <ol className="text-sm text-gray-600 leading-relaxed space-y-2 list-decimal pl-5">
                <li>Ralat, koreksi, dan hak jawab mengacu pada Undang-Undang Pers, Kode Etik Jurnalistik, dan Pedoman Hak Jawab yang ditetapkan Dewan Pers.</li>
                <li>Ralat, koreksi, dan/atau hak jawab wajib ditautkan pada berita yang diralat, dikoreksi, dan/atau yang diberi hak jawab.</li>
                <li>Di setiap berita ralat, koreksi, dan hak jawab wajib dicantumkan waktu pemuatan ralat, koreksi, dan/atau hak jawab tersebut.</li>
                <li>Bila berita yang salah tersebut sudah tersebar ke platform lain, media siber wajib mengunggah ralat, koreksi, dan/atau hak jawab di platform tersebut.</li>
              </ol>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Pencabutan Berita
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed mb-3">
                Berita yang sudah dipublikasikan tidak dapat dicabut karena alasan penyensoran dari pihak luar redaksi, kecuali terkait dengan isu SARA, kesusilaan, anak di bawah umur, pengalaman traumatik korban, dan/atau pertimbangan lain yang ditetapkan Dewan Pers.
              </p>
              <p className="text-sm text-gray-600 leading-relaxed">
                Media siber lain wajib mengikuti pencabutan tersebut jika berita yang dimaksud dikutip dari media siber yang telah mencabutnya.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Iklan
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed mb-3">
                Media siber wajib membedakan dengan jelas mana konten berita dan mana konten iklan. Setiap konten iklan dan/atau konten berbayar (advertorial, sponsored content) wajib diberi label yang jelas agar pembaca dapat membedakannya dari konten jurnalistik.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Hak Cipta
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed">
                Seluruh konten yang dipublikasikan di Poristiwa.my.id dilindungi oleh Undang-Undang Hak Cipta. Pengutipan sebagian atau seluruh konten hanya diperkenankan dengan menyebutkan sumber secara jelas dan memberikan tautan aktif ke artikel asli. Pelanggaran hak cipta akan ditindaklanjuti sesuai dengan ketentuan hukum yang berlaku.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="font-serif text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                Sengketa
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed">
                Penilaian akhir atas sengketa mengenai pelaksanaan Pedoman Media Siber ini diselesaikan oleh Dewan Pers.
              </p>
            </section>

            {/* Contact */}
            <div className="mt-10 p-6 bg-red-50 rounded-xl border border-red-100">
              <h3 className="font-serif text-lg font-bold text-red-900 mb-2">Kontak Redaksi</h3>
              <p className="text-sm text-gray-600 mb-3">
                Untuk pengaduan, hak jawab, ralat, atau koreksi, silakan hubungi redaksi melalui:
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li><strong>Email:</strong> redaksi@poristiwa.my.id</li>
                <li><strong>Telepon:</strong> +62 21 5050 1234</li>
                <li><strong>Alamat:</strong> Gedung Poristiwa Media, Lt. 12, Jl. Gatot Subroto Kav. 36-38, Jakarta Selatan 12190</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="text-center mt-8 text-xs text-gray-400">
          <p>Pedoman ini disusun berdasarkan Peraturan Dewan Pers Nomor: 1/Peraturan-DP/III/2012</p>
          <p className="mt-1">Terakhir diperbarui: Januari 2025</p>
        </div>
      </div>
    </div>
  );
}
