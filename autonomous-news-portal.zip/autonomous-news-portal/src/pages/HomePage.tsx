import { Link } from 'react-router-dom';
import { TrendingUp, ChevronRight, Flame } from 'lucide-react';
import NewsCard from '@/components/NewsCard';
import AdSlot from '@/components/AdSlot';
import { articles, CATEGORIES, getCategoryColor, getArticlesByCategory } from '@/data/mockArticles';

export default function HomePage() {
  const heroArticle = articles[0];
  const secondaryArticles = articles.slice(1, 4);
  const latestArticles = articles.slice(4, 10);
  const trendingArticles = [...articles].sort((a, b) => b.views - a.views).slice(0, 6);
  const editorPicks = articles.slice(5, 9);

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <NewsCard article={heroArticle} variant="hero" />
          </div>
          <div className="flex flex-col gap-3">
            {secondaryArticles.map(a => (
              <NewsCard key={a.id} article={a} variant="horizontal" />
            ))}
          </div>
        </div>
      </section>

      {/* Ad Banner */}
      <section className="mt-8">
        <AdSlot type="leaderboard" />
      </section>

      {/* Main Content Grid */}
      <section className="max-w-7xl mx-auto px-4 mt-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Column */}
          <div className="lg:col-span-2">
            {/* Latest News */}
            <div className="mb-10">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-serif text-2xl font-black text-gray-900 flex items-center gap-2">
                  <span className="w-1.5 h-7 bg-red-700 rounded-full inline-block"></span>
                  Berita Terbaru
                </h2>
                <span className="text-xs text-gray-400 font-medium uppercase tracking-wider">Intisari Peristiwa</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {latestArticles.map(a => (
                  <NewsCard key={a.id} article={a} />
                ))}
              </div>
            </div>

            {/* Ad */}
            <AdSlot type="banner" className="mb-10" />

            {/* Category Sections */}
            {['Ekonomi', 'Teknologi', 'Olahraga'].map(cat => {
              const catArticles = getArticlesByCategory(cat);
              if (catArticles.length === 0) return null;
              return (
                <div key={cat} className="mb-10">
                  <div className="flex items-center justify-between mb-5">
                    <h2 className="font-serif text-xl font-bold text-gray-900 flex items-center gap-2">
                      <span className={`w-1.5 h-6 rounded-full inline-block ${getCategoryColor(cat)}`}></span>
                      {cat}
                    </h2>
                    <Link
                      to={`/category/${cat.toLowerCase()}`}
                      className="text-xs text-red-700 font-semibold flex items-center gap-1 hover:gap-2 transition-all"
                    >
                      Lihat Semua <ChevronRight size={14} />
                    </Link>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {catArticles.slice(0, 2).map(a => (
                      <NewsCard key={a.id} article={a} />
                    ))}
                  </div>
                  {catArticles.length > 2 && (
                    <div className="mt-3 space-y-1">
                      {catArticles.slice(2, 5).map(a => (
                        <NewsCard key={a.id} article={a} variant="horizontal" />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Trending */}
            <div className="glass-card rounded-xl p-5 mb-6 sticky top-36">
              <h3 className="font-serif text-lg font-bold text-gray-900 flex items-center gap-2 mb-4">
                <Flame size={18} className="text-red-600" />
                Populer Hari Ini
              </h3>
              <div className="divide-y divide-gray-100">
                {trendingArticles.map((a, i) => (
                  <Link
                    key={a.id}
                    to={`/news/${a.slug}`}
                    className="group flex items-start gap-3 py-3 first:pt-0 last:pb-0"
                  >
                    <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-red-50 text-red-700 text-sm font-black flex items-center justify-center">
                      {i + 1}
                    </span>
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-gray-800 leading-snug line-clamp-2 group-hover:text-red-700 transition-colors">
                        {a.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`inline-block px-1.5 py-0.5 text-[9px] font-bold text-white rounded ${getCategoryColor(a.category)}`}>
                          {a.category}
                        </span>
                        <span className="text-[10px] text-gray-400">{a.views.toLocaleString('id-ID')} dilihat</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Ad Rectangle */}
            <AdSlot type="rectangle" className="mb-6" />

            {/* Editor's Picks */}
            <div className="glass-card rounded-xl p-5 mb-6">
              <h3 className="font-serif text-lg font-bold text-gray-900 flex items-center gap-2 mb-4">
                <TrendingUp size={18} className="text-red-600" />
                Pilihan Redaksi
              </h3>
              <div className="space-y-3">
                {editorPicks.map(a => (
                  <NewsCard key={a.id} article={a} variant="horizontal" />
                ))}
              </div>
            </div>

            {/* Category Tags */}
            <div className="glass-card rounded-xl p-5">
              <h3 className="font-serif text-lg font-bold text-gray-900 mb-4">Topik</h3>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map(cat => (
                  <Link
                    key={cat}
                    to={`/category/${cat.toLowerCase().replace(' ','-')}`}
                    className={`px-3 py-1.5 text-xs font-semibold text-white rounded-lg ${getCategoryColor(cat)} hover:opacity-90 transition-opacity category-badge`}
                  >
                    {cat}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Ad */}
      <section className="mt-8">
        <AdSlot type="leaderboard" />
      </section>
    </div>
  );
}
