import { useParams, Link } from 'react-router-dom';
import { useEffect } from 'react';
import { Clock, Eye, Share2, BookmarkPlus, ChevronRight, ArrowLeft } from 'lucide-react';
import NewsCard from '@/components/NewsCard';
import AdSlot from '@/components/AdSlot';
import { getArticleBySlug, getRelatedArticles, formatDate, formatViews, getCategoryColor, articles } from '@/data/mockArticles';

export default function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const article = getArticleBySlug(slug || '');

  // Inject JSON-LD via useEffect (proper way in React)
  useEffect(() => {
    if (!article) return;

    const jsonLd = {
      "@context": "https://schema.org",
      "@type": "NewsArticle",
      "headline": article.title,
      "description": article.summary,
      "image": article.image_url,
      "datePublished": article.created_at,
      "dateModified": article.updated_at,
      "author": {
        "@type": "Organization",
        "name": "Poristiwa Media Group"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Poristiwa Media Group",
        "logo": {
          "@type": "ImageObject",
          "url": "https://poristiwa.my.id/favicon.svg"
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": `https://poristiwa.my.id/news/${article.slug}`
      }
    };

    const breadcrumbLd = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Beranda", "item": "https://poristiwa.my.id" },
        { "@type": "ListItem", "position": 2, "name": article.category, "item": `https://poristiwa.my.id/category/${article.category.toLowerCase()}` },
        { "@type": "ListItem", "position": 3, "name": article.title }
      ]
    };

    // Create and inject script elements into <head>
    const script1 = document.createElement('script');
    script1.type = 'application/ld+json';
    script1.textContent = JSON.stringify(jsonLd);
    script1.setAttribute('data-jsonld', 'article');
    document.head.appendChild(script1);

    const script2 = document.createElement('script');
    script2.type = 'application/ld+json';
    script2.textContent = JSON.stringify(breadcrumbLd);
    script2.setAttribute('data-jsonld', 'breadcrumb');
    document.head.appendChild(script2);

    // Update document title
    document.title = `${article.title} — Poristiwa.my.id`;

    // Cleanup on unmount
    return () => {
      document.head.querySelectorAll('script[data-jsonld]').forEach(el => el.remove());
      document.title = 'Poristiwa.my.id — Nadi Peristiwa, Detak Digital';
    };
  }, [article]);

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="font-serif text-4xl font-black text-gray-900 mb-4">404</h1>
          <p className="text-gray-500 mb-6">Artikel tidak ditemukan</p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 bg-red-700 text-white rounded-lg hover:bg-red-800 transition-colors text-sm font-medium">
            <ArrowLeft size={16} />
            Kembali ke Beranda
          </Link>
        </div>
      </div>
    );
  }

  const related = getRelatedArticles(article);
  const catColor = getCategoryColor(article.category);

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-xs text-gray-400">
            <Link to="/" className="hover:text-red-700 transition-colors">Beranda</Link>
            <ChevronRight size={12} />
            <Link to={`/category/${article.category.toLowerCase().replace(' ','-')}`} className="hover:text-red-700 transition-colors">
              {article.category}
            </Link>
            <ChevronRight size={12} />
            <span className="text-gray-600 truncate max-w-xs">{article.title}</span>
          </nav>
        </div>
      </div>

      {/* Article Content */}
      <div className="max-w-7xl mx-auto px-4 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Article */}
          <article className="lg:col-span-2">
            {/* Category Badge */}
            <span className={`inline-block px-3 py-1 text-xs font-bold text-white rounded-md ${catColor} uppercase tracking-wider mb-4`}>
              {article.category}
            </span>

            {/* Title */}
            <h1 className="font-serif text-3xl md:text-4xl lg:text-[2.75rem] font-black text-gray-900 leading-tight mb-4">
              {article.title}
            </h1>

            {/* Summary */}
            <p className="text-lg text-gray-500 leading-relaxed mb-5 font-light">
              {article.summary}
            </p>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400 mb-6 pb-6 border-b border-gray-200">
              <span className="flex items-center gap-1.5">
                <Clock size={14} />
                {formatDate(article.created_at)}
              </span>
              <span className="flex items-center gap-1.5">
                <Eye size={14} />
                {formatViews(article.views)} dilihat
              </span>
              <span className="text-gray-300">|</span>
              <span className="text-red-700 font-medium">Sumber: {article.source_name}</span>
              <div className="flex-1" />
              <button className="flex items-center gap-1.5 text-gray-400 hover:text-red-700 transition-colors">
                <Share2 size={14} />
                <span className="text-xs">Bagikan</span>
              </button>
              <button className="flex items-center gap-1.5 text-gray-400 hover:text-red-700 transition-colors">
                <BookmarkPlus size={14} />
                <span className="text-xs">Simpan</span>
              </button>
            </div>

            {/* Featured Image */}
            <div className="rounded-xl overflow-hidden mb-8 shadow-lg">
              <img
                src={article.image_url}
                alt={article.title}
                className="w-full aspect-video object-cover"
              />
              <div className="bg-gray-100 px-4 py-2">
                <p className="text-xs text-gray-400 italic">Foto: Ilustrasi — {article.title}</p>
              </div>
            </div>

            {/* Ad in content */}
            <AdSlot type="banner" className="mb-8" />

            {/* Article Body */}
            <div className="article-content" dangerouslySetInnerHTML={{ __html: article.content }} />

            {/* Baca Juga */}
            {related.length > 0 && (
              <div className="mt-8 p-5 bg-red-50 rounded-xl border border-red-100">
                <h3 className="font-serif text-lg font-bold text-red-900 mb-3 flex items-center gap-2">
                  <span className="w-1 h-5 bg-red-700 rounded-full inline-block"></span>
                  Baca Juga
                </h3>
                <ul className="space-y-2">
                  {related.slice(0, 3).map(r => (
                    <li key={r.id}>
                      <Link
                        to={`/news/${r.slug}`}
                        className="text-sm text-red-800 hover:text-red-600 font-medium transition-colors flex items-start gap-2"
                      >
                        <ChevronRight size={14} className="mt-0.5 flex-shrink-0" />
                        {r.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Tags */}
            <div className="mt-8 flex flex-wrap items-center gap-2">
              <span className="text-sm text-gray-500 font-medium">Topik:</span>
              <Link
                to={`/category/${article.category.toLowerCase().replace(' ','-')}`}
                className={`px-3 py-1 text-xs font-semibold text-white rounded-lg ${catColor} hover:opacity-90 transition-opacity`}
              >
                {article.category}
              </Link>
            </div>

            {/* Bottom Ad */}
            <AdSlot type="banner" className="mt-8" />

            {/* Related Articles Grid */}
            {related.length > 0 && (
              <div className="mt-10">
                <h3 className="font-serif text-xl font-bold text-gray-900 mb-5 flex items-center gap-2">
                  <span className="w-1.5 h-6 bg-red-700 rounded-full inline-block"></span>
                  Berita Terkait
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {related.map(a => (
                    <NewsCard key={a.id} article={a} />
                  ))}
                </div>
              </div>
            )}
          </article>

          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-36 space-y-6">
              {/* Trending Sidebar */}
              <div className="glass-card rounded-xl p-5">
                <h3 className="font-serif text-lg font-bold text-gray-900 mb-4">Populer</h3>
                <div className="divide-y divide-gray-100">
                  {[...articles].sort((a, b) => b.views - a.views).slice(0, 5).map((a, i) => (
                    <Link
                      key={a.id}
                      to={`/news/${a.slug}`}
                      className="group flex items-start gap-3 py-3 first:pt-0 last:pb-0"
                    >
                      <span className="flex-shrink-0 w-7 h-7 rounded-md bg-red-50 text-red-700 text-xs font-black flex items-center justify-center">
                        {i + 1}
                      </span>
                      <h4 className="text-sm font-medium text-gray-700 line-clamp-2 group-hover:text-red-700 transition-colors">
                        {a.title}
                      </h4>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Ad */}
              <AdSlot type="rectangle" />
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
