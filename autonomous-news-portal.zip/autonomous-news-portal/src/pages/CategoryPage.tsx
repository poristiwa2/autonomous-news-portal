import { useParams, Link } from 'react-router-dom';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import NewsCard from '@/components/NewsCard';
import AdSlot from '@/components/AdSlot';
import { articles, CATEGORIES, getCategoryColor } from '@/data/mockArticles';

export default function CategoryPage() {
  const { category } = useParams<{ category: string }>();

  const normalizedCat = CATEGORIES.find(
    c => c.toLowerCase().replace(' ', '-') === category?.toLowerCase()
  );

  const catArticles = normalizedCat
    ? articles.filter(a => a.category === normalizedCat)
    : [];

  if (!normalizedCat) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="font-serif text-4xl font-black text-gray-900 mb-4">Kategori Tidak Ditemukan</h1>
          <p className="text-gray-500 mb-6">Halaman kategori yang Anda cari tidak tersedia.</p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 bg-red-700 text-white rounded-lg hover:bg-red-800 transition-colors text-sm font-medium">
            <ArrowLeft size={16} />
            Kembali ke Beranda
          </Link>
        </div>
      </div>
    );
  }

  const catColor = getCategoryColor(normalizedCat);
  const otherCategories = CATEGORIES.filter(c => c !== normalizedCat);

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Category Header */}
      <div className={`${catColor} text-white`}>
        <div className="max-w-7xl mx-auto px-4 py-8">
          <nav className="flex items-center gap-2 text-xs text-white/60 mb-4">
            <Link to="/" className="hover:text-white transition-colors">Beranda</Link>
            <ChevronRight size={12} />
            <span className="text-white font-medium">{normalizedCat}</span>
          </nav>
          <h1 className="font-serif text-3xl md:text-4xl font-black mb-2">{normalizedCat}</h1>
          <p className="text-white/70 text-sm">
            Kumpulan berita terkini seputar {normalizedCat.toLowerCase()} dari redaksi Poristiwa Media Group
          </p>
          <div className="mt-4 text-xs text-white/50">
            {catArticles.length} artikel tersedia
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main */}
          <div className="lg:col-span-2">
            {catArticles.length > 0 && (
              <>
                {/* Featured */}
                <NewsCard article={catArticles[0]} variant="hero" />

                {/* Ad */}
                <AdSlot type="banner" className="mt-6 mb-6" />

                {/* Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mt-6">
                  {catArticles.slice(1).map(a => (
                    <NewsCard key={a.id} article={a} />
                  ))}
                </div>

                {catArticles.length <= 1 && (
                  <div className="mt-8 text-center py-12 glass-card rounded-xl">
                    <p className="text-gray-400 text-sm">Belum ada berita tambahan di kategori ini.</p>
                  </div>
                )}
              </>
            )}

            {catArticles.length === 0 && (
              <div className="text-center py-16 glass-card rounded-xl">
                <p className="text-gray-400 text-lg font-medium mb-2">Belum ada berita</p>
                <p className="text-gray-300 text-sm">Berita di kategori {normalizedCat} akan segera tersedia.</p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-36 space-y-6">
              {/* Other Categories */}
              <div className="glass-card rounded-xl p-5">
                <h3 className="font-serif text-lg font-bold text-gray-900 mb-4">Kategori Lainnya</h3>
                <div className="flex flex-wrap gap-2">
                  {otherCategories.map(cat => (
                    <Link
                      key={cat}
                      to={`/category/${cat.toLowerCase().replace(' ','-')}`}
                      className={`px-3 py-1.5 text-xs font-semibold text-white rounded-lg ${getCategoryColor(cat)} hover:opacity-90 transition-opacity category-badge`}
                    >
                      {cat}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Ad */}
              <AdSlot type="rectangle" />

              {/* Latest from other categories */}
              <div className="glass-card rounded-xl p-5">
                <h3 className="font-serif text-lg font-bold text-gray-900 mb-4">Berita Lainnya</h3>
                <div className="divide-y divide-gray-100">
                  {articles
                    .filter(a => a.category !== normalizedCat)
                    .slice(0, 5)
                    .map(a => (
                      <Link
                        key={a.id}
                        to={`/news/${a.slug}`}
                        className="group block py-3 first:pt-0 last:pb-0"
                      >
                        <span className={`inline-block px-1.5 py-0.5 text-[9px] font-bold text-white rounded ${getCategoryColor(a.category)} mb-1`}>
                          {a.category}
                        </span>
                        <h4 className="text-sm font-medium text-gray-700 line-clamp-2 group-hover:text-red-700 transition-colors">
                          {a.title}
                        </h4>
                      </Link>
                    ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
