import { Link } from 'react-router-dom';
import { ChevronRight, BarChart3, Users, Globe, Zap, Mail, Phone, CheckCircle2 } from 'lucide-react';

export default function PasangIklan() {
  const stats = [
    { icon: Users, label: 'Pengunjung Unik/Bulan', value: '2.5 Juta+' },
    { icon: BarChart3, label: 'Pageviews/Bulan', value: '8 Juta+' },
    { icon: Globe, label: 'Jangkauan Nasional', value: '34 Provinsi' },
    { icon: Zap, label: 'Engagement Rate', value: '4.2%' },
  ];

  const packages = [
    {
      name: 'Display Banner',
      desc: 'Banner iklan di posisi strategis halaman utama dan artikel',
      price: 'Rp 5.000.000',
      period: '/bulan',
      features: ['Banner 728×90 di header', 'Banner 300×250 di sidebar', 'Rotasi di seluruh halaman', 'Laporan performa mingguan'],
      popular: false,
    },
    {
      name: 'Native Advertorial',
      desc: 'Artikel sponsor yang dikemas sebagai konten editorial berkualitas tinggi',
      price: 'Rp 15.000.000',
      period: '/artikel',
      features: ['Ditulis oleh tim redaksi', 'Distribusi ke seluruh kanal', 'SEO optimized', 'Promosi di media sosial', 'Tayang permanen'],
      popular: true,
    },
    {
      name: 'Display Takeover',
      desc: 'Dominasi visual penuh di halaman utama selama periode tertentu',
      price: 'Rp 25.000.000',
      period: '/minggu',
      features: ['Skin/background takeover', 'Banner eksklusif semua posisi', 'Pop-under notification', 'Laporan real-time', 'Account manager dedikasi'],
      popular: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-xs text-gray-400">
            <Link to="/" className="hover:text-red-700 transition-colors">Beranda</Link>
            <ChevronRight size={12} />
            <span className="text-gray-600">Pasang Iklan</span>
          </nav>
        </div>
      </div>

      {/* Hero */}
      <div className="bg-gradient-to-br from-neutral-900 via-neutral-800 to-red-950 text-white">
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <span className="inline-block px-4 py-1.5 bg-red-700/30 text-red-300 text-xs font-bold uppercase tracking-widest rounded-full mb-6 border border-red-700/30">
            Media Kit 2025
          </span>
          <h1 className="font-serif text-4xl md:text-5xl font-black mb-4">
            Jangkau Jutaan Pembaca<br />Aktif Indonesia
          </h1>
          <p className="text-white/60 text-lg max-w-2xl mx-auto mb-10">
            Tingkatkan visibilitas brand Anda melalui platform berita terpercaya dengan audience berkualitas tinggi.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
            {stats.map((s, i) => (
              <div key={i} className="glass-card-dark rounded-xl p-4 text-center">
                <s.icon size={24} className="text-red-400 mx-auto mb-2" />
                <p className="text-2xl font-black text-white">{s.value}</p>
                <p className="text-xs text-white/40 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Packages */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl font-black text-gray-900 mb-3">Paket Iklan</h2>
          <p className="text-gray-500">Pilih format iklan yang sesuai dengan kebutuhan kampanye Anda</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {packages.map((pkg, i) => (
            <div
              key={i}
              className={`glass-card rounded-2xl p-6 relative ${pkg.popular ? 'ring-2 ring-red-600 shadow-xl shadow-red-100' : ''}`}
            >
              {pkg.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-red-700 text-white text-xs font-bold rounded-full uppercase tracking-wider">
                  Populer
                </span>
              )}
              <h3 className="font-serif text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
              <p className="text-sm text-gray-500 mb-4">{pkg.desc}</p>
              <div className="mb-6">
                <span className="text-3xl font-black text-gray-900">{pkg.price}</span>
                <span className="text-sm text-gray-400">{pkg.period}</span>
              </div>
              <ul className="space-y-2 mb-6">
                {pkg.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm text-gray-600">
                    <CheckCircle2 size={16} className="text-emerald-500 flex-shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href="mailto:iklan@poristiwa.my.id"
                className={`block text-center py-2.5 rounded-lg font-semibold text-sm transition-all ${
                  pkg.popular
                    ? 'bg-red-700 text-white hover:bg-red-800'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Hubungi Tim Iklan
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Contact CTA */}
      <div className="bg-red-50 border-t border-red-100">
        <div className="max-w-3xl mx-auto px-4 py-12 text-center">
          <h3 className="font-serif text-2xl font-bold text-gray-900 mb-3">Butuh Solusi Khusus?</h3>
          <p className="text-gray-500 mb-6">Tim komersial kami siap membantu merancang kampanye iklan yang sesuai dengan kebutuhan spesifik brand Anda.</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="mailto:iklan@poristiwa.my.id" className="inline-flex items-center gap-2 px-6 py-3 bg-red-700 text-white rounded-lg hover:bg-red-800 transition-colors font-semibold text-sm">
              <Mail size={16} />
              iklan@poristiwa.my.id
            </a>
            <a href="tel:+622150501234" className="inline-flex items-center gap-2 px-6 py-3 bg-white text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold text-sm border border-gray-200">
              <Phone size={16} />
              +62 21 5050 1234
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
